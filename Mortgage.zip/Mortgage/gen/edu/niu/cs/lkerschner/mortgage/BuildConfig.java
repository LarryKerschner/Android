/** Automatically generated file. DO NOT MODIFY */
package edu.niu.cs.lkerschner.mortgage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}